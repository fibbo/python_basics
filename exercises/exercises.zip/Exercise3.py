import math


def volume_from_radius(r):
    return 4*math.pi/3 * r ** 3


radius = int(input('Radius: '))
print(volume_from_radius(radius))